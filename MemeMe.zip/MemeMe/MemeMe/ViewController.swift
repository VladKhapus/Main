//
//  ViewController.swift
//  MemeMe
//
//  Created by Vlad on 12/4/17.
//  Copyright © 2017 Vlad. All rights reserved.
//

import UIKit
import Social
import Photos

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    
    
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var TopTextField: UITextField!
    @IBOutlet weak var BottomTextField: UITextField!
    @IBOutlet weak var BottomToolBar: UIToolbar!
    @IBOutlet weak var TopToolBar: UIToolbar!
    @IBOutlet weak var CameraButton: UIBarButtonItem!
    
    var memedImage = UIImage()
    var Images: [String] = []
    var imageArray = [UIImage]()
    
    override func viewDidLoad() {
        let memeTextAttributes:[String:Any] = [
            NSAttributedStringKey.strokeColor.rawValue: UIColor.black,
            NSAttributedStringKey.foregroundColor.rawValue: UIColor.white,
            NSAttributedStringKey.font.rawValue: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSAttributedStringKey.strokeWidth.rawValue: -4 ]
        
        TopTextField.defaultTextAttributes = memeTextAttributes
        
        BottomTextField.defaultTextAttributes = memeTextAttributes
        
        BottomTextField.delegate = self
        TopTextField.delegate = self
        
        BottomTextField.textAlignment = .center
        TopTextField.textAlignment = .center

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
        
        CameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    @objc func keyboardWillShow(_ notification:Notification) {
        if BottomTextField.isFirstResponder {
            view.frame.origin.y = 0 - getKeyboardHeight(notification)
        }
    }
    func horizontalKeyboardWillShow(_ notifictaion:Notification){
        if BottomTextField.isFirstResponder{
            view.frame.origin.x = 0 - getKeyboardHeight(notifictaion)
        }
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }

    //Share Button
    
    @IBAction func Share(_ sender: Any) {
        let ButtonPressed = UIActivityViewController(activityItems: [self.ImageView.image as Any], applicationActivities: nil)
        ButtonPressed.popoverPresentationController?.sourceView = self.view
        present(ButtonPressed, animated: true, completion: nil)
        
        let memedImage = generateMemedImage()
        let controller = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        controller.completionWithItemsHandler = {(activity, completed, items, error) in
            if (completed) {
                self.save()
                self.dismiss(animated:true,completion:nil)
            }
        }
        self.present(controller, animated: true, completion: nil)
    }
    
    //Camera
    
    @IBAction func Camera(_ sender: UIBarButtonItem) {
        
        let picker = UIImagePickerController()
        
        picker.delegate = self
        picker.sourceType = .camera
        
        present(picker, animated: true, completion: nil)
        
    }
    
    
    //Album
    
    @IBAction func Album(_ sender: UIBarButtonItem) {
        
        let image = UIImagePickerController()
        image.delegate = self
        
        image.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
        image.allowsEditing = false
        
        self.present(image, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            ImageView.image = image
        }else{
            print ("You didnt allow e to access you PhotoLibrary!")
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    //Sliding KeyBoard
    
    var activeTextField : UITextField!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeTextField = textField
    }
    
    
    @objc func keyboardWillHide(notification: Notification) {
        view.frame.origin.y = 0
    }
    
    
    func save() {
        // Create the meme
        let memes = Meme(TopTextField: TopTextField.text!, BottomTextField: BottomTextField.text!, ImageView: ImageView.image, memedImage: memedImage)
        
        // Add it to the memes array in the Application Delegate
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(memes)
    }
    
    func generateMemedImage() -> UIImage {
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        return memedImage
    }
}
    


