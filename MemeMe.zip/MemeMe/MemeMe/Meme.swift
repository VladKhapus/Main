//
//  Meme.swift
//  MemeMe
//
//  Created by Vlad on 1/3/18.
//  Copyright © 2018 Vlad. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    var TopTextField:String = "Top"
    var BottomTextField:String = "Bottom"
    var ImageView:UIImage?
    var memedImage:UIImage?
}
