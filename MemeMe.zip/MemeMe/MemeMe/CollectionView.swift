//
//  CollectionView.swift
//  MemeMe
//
//  Created by Vlad on 12/28/17.
//  Copyright © 2017 Vlad. All rights reserved.
//

import Foundation

class CollectionView: UICollectionViewController {
    
}
