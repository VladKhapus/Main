//
//  Table view.swift
//  MemeMe
//
//  Created by Vlad on 12/29/17.
//  Copyright © 2017 Vlad. All rights reserved.
//

import Foundation
import UIKit

struct imageTableView {
    
    let name: TopTextField 
    
}
