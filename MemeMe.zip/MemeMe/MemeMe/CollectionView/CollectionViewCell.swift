//
//  CollectionViewCell.swift
//  MemeMe
//
//  Created by Vlad on 12/31/17.
//  Copyright © 2017 Vlad. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    let Images = [UIImage(named: "1"), UIImage(named: "2"), UIImage(named: "3"), UIImage(named: "4"),]
    
    let Name = ["Image 1","Image 2","Image 3","Image 4"]

    @IBOutlet weak var myImage: UIImageView!
    
    @IBOutlet weak var memeName: UILabel!
    
    
}
