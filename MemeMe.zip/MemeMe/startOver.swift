//
//  ViewController.swift
//  MemeMe
//
//  Created by Vlad on 1/19/18.
//  Copyright © 2018 Vlad. All rights reserved.
//

import UIKit

class startOver: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let plusButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(tapButton))
        self.navigationItem.rightBarButtonItem = plusButton
    }
    
    @objc func tapButton(){
        let viewController:UIViewController = storyboard!.instantiateViewController(withIdentifier: "ViewController") as UIViewController
        self.present(viewController , animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
